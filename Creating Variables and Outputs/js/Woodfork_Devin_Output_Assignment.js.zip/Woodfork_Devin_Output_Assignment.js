/**
 * Devin Woodfork
 * SOI 1508
 * Creating Variables and Output.
 */


 var age;
 age = 23;

 var fullName;
 name = "Devin Woodfork";

 var city;
 city = "Memphis";

 var isLegal = true;

 var isIllegal = false;

  isLegal >= 18

  isIllegal < 18





alert ("My name is" + " " + name + " " + "and I am" + " " + age + "." + " " +
    "I am from" + " " + city + " and according to my age when asked if I am of legal" +
    " age the answer is always" + " " +  isLegal + "." + "I am a Web Design and Developer Major at Full" +
    "Sail University Online." );